int multIA(int m, int n){
    int result = 0;
    for(int i=0; i<n-1; i++){
    	    result += m;
    }
    return result;
}