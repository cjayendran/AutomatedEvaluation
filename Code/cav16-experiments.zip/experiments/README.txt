The structure of the benchmark directory is as follows:

Each problem has a separate sub-directory labelled with the problem name. Each directory consists of the following 4 files:
1) problem.cs -- the buggy student file
2) problem-syntactic.sk -- the sketch file encoding the syntactic distance
3) problem-semantic.sk -- the sketch file encoding the semantic distance
4) problem-combined.sk -- the sketch file encoding the combined syntactic and semantic distances


Instructions to run the experiments:

First install sketch from: https://bitbucket.org/gatoatigrado/sketch-frontend/wiki/Installation

Then type the following command to run the sketch files:

sketch --fe-tempdir <dirName> --bnd-int-range 200 --bnd-arr-size 5 --bnd-unroll-amnt 5 problem-distance.sk
