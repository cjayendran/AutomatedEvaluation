Input.txt contains the test cases in specified format
GoldStandard.txt contains the correct solutions
Output.txt conatins the solutions given by a student's program
--------------------------------------------------------------
To run: java Test file1.c file2.c .... filen.c
Example: java Test check.c check2.c
--------------------------------------------------------------
Correct Solutions will be moved to Approaches
Incorrect Solutions will be moved to Fails
--------------------------------------------------------------
