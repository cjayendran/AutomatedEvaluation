#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
	FILE *f, *p;
	int t,n,i,j,a[1000];
	
	f = fopen(argv[1],"r");
	p = fopen(argv[2],"w");
	
	fscanf(f,"%d",&t);
	
	for(i=0;i<t;i++)
	{
		int sum = 0;
		fscanf(f,"%d",&n);
		for(j=0;j<n;j++)
		{
			fscanf(f,"%d",&a[j]);
			sum = sum + a[j];
		}
		fprintf(p,"%d\n",sum);
	}
	return 0;
}
