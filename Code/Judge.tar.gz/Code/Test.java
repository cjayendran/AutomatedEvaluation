import java.lang.*;
import java.io.*;

public class Test {
	static String javaCompile = "javac";
	static String javaExec = "java";
	
	public static void main(String args[]) {
		String[] compileCommand = null;
		String[] execCommand = null;
		for(int i=0; i<args.length; i++) {
			compileCommand = new String[]{javaCompile, "Judge.java"};
			execCommand = new String[]{javaExec, "Judge", args[i]};
			ProcessBuilder builder = new ProcessBuilder(compileCommand);	
			Process comp =  null;
		
			try { 
				comp = builder.start();
			} 
			catch(IOException e) {
				System.out.println("ERROR");
		  	}
		  	
		  	int compileResult = -1;
			try {
				compileResult = comp.waitFor();
			} 
			catch (InterruptedException e) {
				System.out.println("ERROR");
			}
			if (compileResult != 0) { 
				System.out.println("COMPILE FAIL");
				System.out.println("GOLD STANDARDS EVALUATION ABORT");
				return;
			}
			ProcessBuilder runner = new ProcessBuilder(execCommand);		
			Process run = null;
			try {
				run = runner.start();
			} 
			catch(IOException e) {
				System.out.println("ERROR");
		  	}
		}
	}
}
