import java.lang.*;
import java.io.*;

public class Judge {
	static String cCompile = "gcc";
	
	public static void main(String[] args) {
		String fName = "";
	
		if (args.length == 0) {
		    System.out.println("PROVIDE FILE NAME");
		    return;
		    
		}
		File destinationFolder = new File("Approaches");
		if (!destinationFolder.exists()) {
        		destinationFolder.mkdirs();
    		}
    		
    		File destinationFolder2 = new File("Fails");
		if (!destinationFolder2.exists()) {
        		destinationFolder2.mkdirs();
    		}
    		
		fName = args[0];
		String compileCommand[] = new String[]{cCompile, fName, "-o", "exec"};
		String execCommand[] = new String[]{"./exec","input.txt", "output.txt"};
		ProcessBuilder builder = new ProcessBuilder(compileCommand);	
		Process comp =  null;
		
		try { 
			comp = builder.start();
		} 
		catch(IOException e) {
			System.out.println("ERROR");
	  	}
	  	
	  	int compileResult = -1;
		try {
			compileResult = comp.waitFor();
		} 
		catch (InterruptedException e) {
			System.out.println("ERROR");
		}
		if (compileResult != 0) { 
			System.out.println("COMPILE FAIL");
			System.out.println("GOLD STANDARDS EVALUATION ABORT");
			return;
		}
		ProcessBuilder runner = new ProcessBuilder(execCommand);		
		Process run = null;
		try {
			new File("input.txt").createNewFile();
			new File("output.txt").createNewFile();
			runner.redirectInput(new File("input.txt")); 
			runner.redirectOutput(new File("output.txt")); 
			run = runner.start();
		} 
		catch(IOException e) {
			System.out.println("ERROR");
	  	} 	
		BufferedReader bro = null, brg = null;
		FileReader fro = null, frg = null;
		try {
			int check = 0, count = 0, c = 0;
			fro = new FileReader("output.txt");
			bro = new BufferedReader(fro);
			frg = new FileReader("GoldStandard.txt");
			brg = new BufferedReader(frg);			
			String s1, s2;
			while ((s1 = bro.readLine()) != null && (s2 = brg.readLine()) != null) {
				if(!(s1.equals(s2))) {
					count++;
					check = 1;
				}
			}
			if(check == 1) {
				System.out.println(fName + " is not a gold standard");
				File afile = new File(fName);
				afile.renameTo(new File("Fails/" + afile.getName()));
			}
			if(check == 0) {
				System.out.println(fName + " is a gold standard");	
				File afile = new File(fName);
				afile.renameTo(new File("Approaches/" + afile.getName()));
			}
			fro.close();
			bro.close();
			frg.close();
			brg.close();
			File dfile = new File("output.txt");
			dfile.delete();
		
		} 
		catch (IOException e) {
			e.printStackTrace();
		} 
	}					
}
	

